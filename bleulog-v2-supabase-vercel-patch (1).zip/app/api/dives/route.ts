import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

function rowToDive(row: any) {
  return {
    ...(row.payload ?? {}),
    id: row.id,
    diveNumber: row.dive_number ?? row.payload?.diveNumber ?? 0,
    date: row.date ?? row.payload?.date ?? "",
    location: row.location ?? row.payload?.location ?? "",
    country: row.country ?? row.payload?.country ?? "",
    buddy: row.buddy ?? row.payload?.buddy ?? "",
    latitude: row.latitude ?? row.payload?.latitude ?? 0,
    longitude: row.longitude ?? row.payload?.longitude ?? 0,
  };
}

export async function GET() {
  const { data, error } = await supabaseAdmin
    .from("dives")
    .select("*")
    .order("dive_number", { ascending: false });

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json((data ?? []).map(rowToDive));
}

export async function POST(request: Request) {
  const dive = await request.json();

  const row = {
    id: dive.id,
    dive_number: dive.diveNumber ?? 0,
    date: dive.date || null,
    location: dive.location ?? "",
    country: dive.country ?? "",
    buddy: dive.buddy ?? "",
    latitude: dive.latitude || null,
    longitude: dive.longitude || null,
    payload: dive,
  };

  const { error } = await supabaseAdmin.from("dives").insert(row);

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return new NextResponse(null, { status: 204 });
}
