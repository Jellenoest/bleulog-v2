import { NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabaseAdmin";

export async function GET() {
  const { data, error } = await supabaseAdmin
    .from("dive_sites")
    .select("*")
    .order("country")
    .order("name");

  if (error) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }

  return NextResponse.json(
    (data ?? []).map((site) => ({
      id: site.id,
      code: site.code,
      name: site.name,
      country: site.country,
      countryCode: site.country_code,
      region: site.region,
      latitude: site.latitude,
      longitude: site.longitude,
      waterType: site.water_type,
      entryType: site.entry_type,
      difficulty: site.difficulty,
      maxDepth: site.max_depth,
      description: site.description,
    }))
  );
}
